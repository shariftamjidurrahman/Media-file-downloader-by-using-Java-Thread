public class Constants {
    public static final String PART_EXTENSION = ".part";
}
