public class Main {
    public static void main(String[] args) {
//        System.out.println("Hello world!");
        final String downloadDir = "./";
        final String url = "http://www.sample-videos.com/videos/mp4/720/big_buck_bunny_720p_10mb.mp4";
        DownloadManager downloadManager = new DownloadManager();
        downloadManager.download(url,downloadDir);

    }
}